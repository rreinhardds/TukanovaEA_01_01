﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TukanovaEA_01_01
{
    public class NutritionChildren : Nutrition
    {
        public double P;
        public double Qp;
        public NutritionChildren(string name, double protein, double carbohydrate) : base(name, protein, carbohydrate)
        {
            name = Name;
            protein = Protein;
            carbohydrate = Carbohydrate;
            P = 1;
            Qp = Quality();
        }
        public virtual double Quality() //функция для класса потомка
        {
            return Q*1.2+P*7;
        }
        public override void PrintInfo() //вывод информации
        {
            Console.WriteLine($"Название продукта:{Name}\nКол-во белка:{Protein}\n Кол-во углеводов:{Carbohydrate}\n Qp - {Qp}\n Q - {Q}");
        }
    }
}
