﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TukanovaEA_01_01
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите название продукта:");
            string name=Console.ReadLine();
            Console.WriteLine("Введите кол-во белка в продукте:");
            double protein=Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Введите кол-во углеводов в продукте:");
            double carbohydrate=Convert.ToDouble(Console.ReadLine());

            Nutrition nutrition=new Nutrition(name, protein, carbohydrate);
            nutrition.PrintInfo();
            NutritionChildren nutritionChildren=new NutritionChildren("Лапша", 50, 40); 
            nutritionChildren.PrintInfo();
        }
    }
}
