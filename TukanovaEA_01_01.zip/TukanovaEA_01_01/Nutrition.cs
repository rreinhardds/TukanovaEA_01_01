﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TukanovaEA_01_01
{
    public class Nutrition
    {
        public string Name { get; set; } //поле наименования товара
        public double Protein { get; set; } //поле количество белка
        public double Carbohydrate { get; set; } // поле количества углевода
        public double Q { get; set; } //поле значения Q
        public Nutrition(string name, double protein, double carbohydrate) 
        {
            Name = name;
            Protein = protein;
            Carbohydrate = carbohydrate;
            Q = Quality();
        }
        public virtual double Quality() //функция для базового класса
        {
            return (int)(Carbohydrate * 4 + Protein * 4);
        }
        public virtual void PrintInfo() //вывод информации
        {
            Console.WriteLine($"Название продукта:{Name}\n Кол-во белка:{Protein}\n Кол-во углеводов:{Carbohydrate}\n Q - {Q}");
        }

}
   
}
