using TukanovaEA_01_01;

namespace TestNutrition
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
            double expected = 440;
            Nutrition nutrition = new Nutrition("���", 50, 60);
            Assert.Equal(expected, nutrition. Q);

        }
        [Fact]
        public void Test2()
        {
            double expected = 642;
            Nutrition nutrition = new Nutrition("�����", 100, 60.7);
            Assert.Equal(expected, nutrition.Q);

        }
        [Fact]
        public void Test3()
        {
            double expected = 487;
            NutritionChildren nutritionChildren = new NutritionChildren("���", 30,70);
            Assert.Equal(expected, nutritionChildren.Qp);

        }
        [Fact]
        public void Test4()
        {
            double expected = 535;
            NutritionChildren nutritionChildren = new NutritionChildren("�����", 60, 50);
            Assert.Equal(expected, nutritionChildren.Qp);

        }
    }
}